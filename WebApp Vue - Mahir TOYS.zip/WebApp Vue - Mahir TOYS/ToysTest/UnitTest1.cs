using Microsoft.VisualStudio.TestTools.UnitTesting;
using ToysLib;
using System;

namespace ToysLib.Tests
{
    [TestClass]
    public class ToyTests
    {
        [TestMethod]
        public void BrandValidValue()
        {
            // Arrange
            var toy = new Toy { Brand = "Lego", Price = 100 };  
            // Act
            toy.Validate(); 
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "Brand skal v�re mindst 2 tegn lang.")]
        public void BrandTooShortShouldThrowException()
        {
            // Arrange
            var toy = new Toy { Brand = "L", Price = 100 }; 

            // Act
            toy.Validate(); 
        }

        [TestMethod]
        public void PriceValidValueShouldPass()
        {
            // Arrange
            var toy = new Toy { Brand = "Lego", Price = 1.00m}; 

            // Act and Assert
            toy.Validate(); // Should not throw
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "Price skal v�re et positivt tal.")]
        public void PriceNegativeValueShouldException()
        {
            // Arrange
            var toy = new Toy { Brand = "Lego", Price = -1.00m }; 

            // Act
            toy.Validate(); // Should throw because of Price
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "Price skal v�re et positivt tal.")]
        public void PriceZeroShoulThrowException()
        {
            // Arrange
            var toy = new Toy { Brand = "Lego", Price = 0.00m };

            // Act
            toy.Validate(); // Should throw because of Price
        }
    }
}
