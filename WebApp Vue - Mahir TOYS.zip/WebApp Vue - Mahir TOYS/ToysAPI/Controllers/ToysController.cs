﻿using Microsoft.AspNetCore.Mvc;
using ToysLib;
using System.Collections.Generic;
using System.Linq;

namespace ToysLib.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ToysController : ControllerBase
    {
        private readonly ToysRepository _repository;

        public ToysController(ToysRepository repository)
        {
            _repository = repository;
        }

        // GET: /Toys
        [HttpGet]
        public ActionResult<IEnumerable<Toy>> GetAllToys()
        {
            var toys = _repository.GetAll();
            return Ok(toys);
        }

        // GET: /Toys/{id}
        [HttpGet("{id}")]
        public ActionResult<Toy> GetToyById(int id)
        {
            var toy = _repository.GetById(id);
            if (toy == null)
            {
                return NotFound();
            }
            return Ok(toy);
        }

        // POST: /Toys
        [HttpPost]
        public ActionResult<Toy> AddToy([FromBody] Toy toy)
        {
            if (toy == null)
            {
                return BadRequest("Toy cannot be null.");
            }
            _repository.Add(toy);
            return CreatedAtAction(nameof(GetToyById), new { id = toy.ID }, toy);
        }

        // PUT: /Toys/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateToy(int id, [FromBody] Toy updatedToy)
        {
            if (updatedToy == null)
            {
                return BadRequest("Updated toy cannot be null.");
            }
            var result = _repository.Update(id, updatedToy);
            if (!result)
            {
                return NotFound();
            }
            return Ok(updatedToy); // Return the updated object
        }

        // DELETE: /Toys/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteToy(int id)
        {
            bool result = _repository.Delete(id);
            if (result)
            {
                return Ok(); // Return 200 OK if the deletion was successful
            }
            else
            {
                return NotFound(); // Return 404 Not Found if the toy was not found
            }
        }
    }
}
