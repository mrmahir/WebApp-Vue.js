using ToysLib;
using Microsoft.AspNetCore.Cors;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddSingleton<ToysRepository>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add CORS services
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "AllowAll",
                      policy =>
                      {
                          policy.AllowAnyOrigin() // WARNING: Only use this setting for development purposes!
                                .AllowAnyHeader()
                                .AllowAnyMethod();
                      });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowAll"); // Use the correct CORS policy name

app.UseAuthorization();

app.MapControllers();

app.Run();



// Hvad betyder CORS? Hvordan kan du se om CORS er tilf�jet? 
// Netv�rkstrafik-analyse (Browser Developer Tools):
//�bn developer tools i din browser (normalt ved at trykke F12).
//G� til "Netv�rk" (eller "Network") fanebladet.
//Udf�r en handling, der udl�ser en HTTP-anmodning til serveren.
//Klik p� den specifikke anmodning i netv�rksloggen.
//Se p� response headers. Hvis du ser headers som Access-Control-Allow-Origin eller
//"Fetch Method Cors"
