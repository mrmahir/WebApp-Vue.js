﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace ToysLib
{
    public class ToysRepository
    {
        private readonly List<Toy> _toys = new List<Toy>();
        private int _nextId = 1; // Starting ID for toys

        public ToysRepository()
        {
            // Initialize the repository with some Toy objects
            Add(new Toy { Brand = "Lego", Model = "Star Wars Set", Price = 249.99m });
            Add(new Toy { Brand = "Mattel", Model = "Barbie Dreamhouse", Price = 199.99m });
            Add(new Toy { Brand = "Hasbro", Model = "Monopoly", Price = 19.99m });
            Add(new Toy { Brand = "Bandai", Model = "Tamagotchi", Price = 29.99m });
        }

        public ReadOnlyCollection<Toy> GetAll()
        {
            return _toys.AsReadOnly();
        }

        public Toy GetById(int id)
        {
            var toy = _toys.FirstOrDefault(t => t.ID == id);
            if (toy == null)
            {
                return null;
            }

            return toy;

        }

        public void Add(Toy toy)
        {
            if (toy == null)
            {
                throw new ArgumentNullException(nameof(toy));
            }

            toy.ID = _nextId++;
            _toys.Add(toy);
        }

        public bool Update(int id, Toy updatedToy)
        {
            if (updatedToy == null)
            {
                throw new ArgumentNullException(nameof(updatedToy));
            }

            var toy = GetById(id);
            if (toy == null)
            {
                throw new ArgumentNullException(nameof(toy));
            }

            // Update properties
            toy.Brand = updatedToy.Brand;
            toy.Model = updatedToy.Model;
            toy.Price = updatedToy.Price;

            return true;
        }

        public bool Delete(int id)
        {
            var toy = _toys.FirstOrDefault(t => t.ID == id);
            if (toy != null)
            {
                _toys.Remove(toy);
                return true;
            }
            return false;
        }
    }
}
