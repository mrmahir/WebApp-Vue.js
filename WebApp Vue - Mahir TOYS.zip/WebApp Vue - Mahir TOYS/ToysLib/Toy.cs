﻿using System;

namespace ToysLib
{
    public class Toy
    {
        // Egenskaber
      public int ID { get; set; }
      public string Brand { get; set; }
      public string Model { get; set; }
      public decimal Price { get; set; }


        public Toy(int id, string brand, string model, decimal price ) 
        {
            ID = id;
            Brand = brand;
            Model = model;
            Price = price;
        }

        public Toy() { }

        // Valideringsmetode til at validere alle properties på en gang
        public void Validate()
        {
            if (Brand == null)
            {
                throw new ArgumentNullException(nameof(Brand), "Brand cannot be null.");
            }

            // Validerer Length
            if (Brand.Length < 2)
            {
                throw new ArgumentException("Brand skal være mindst 2 tegn lang.");
            }       

            // Validerer Price
            if (Price <= 0)
            {
                throw new ArgumentException("Price skal være et positivt tal.");
            }
        }

    }
}
